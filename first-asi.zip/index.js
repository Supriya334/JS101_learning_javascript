
var b="NAMES:-"
var name="Shiva";
var name2="Gauri";
var name3="Shakti";
console.log(b,name,name2,name3);
var c="SCHOOLS||"

var school="army"
var school2="army2"
var school3="army3"
console.log(c,school,school2,school3);
var c="GRADES "
var grade="A"
var grade2="B"
var grade3="C"
console.log(c,grade,grade2,grade3)
var d="SECTIONS~"
var section="f"
var section2="h"
var section3="i"
console.log(d,section,section2,section)


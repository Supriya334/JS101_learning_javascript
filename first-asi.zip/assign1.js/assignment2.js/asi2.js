let name="supriya";
console.log(name);
let name="rajjan singh";
console.log(name);
let name="girija devi";
console.log(name);


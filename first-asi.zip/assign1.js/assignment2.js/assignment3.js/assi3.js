var name="supriya"
var age="22"
console.log(typeof(name))
console.log(typeof(age))
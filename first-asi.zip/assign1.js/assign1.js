var a="Masai School";
var b="A Transformation in Education";
console.log(a,b)
